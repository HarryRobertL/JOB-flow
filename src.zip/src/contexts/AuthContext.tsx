/**
 * Auth Context
 * 
 * Provides authentication state and functions for the entire app.
 * Uses React Context API to store user session information.
 */

import * as React from "react"
import { apiPost, apiGet } from "@/lib/apiClient"

export type Role = "claimant" | "coach" | "admin"

export interface User {
  id: string
  email: string
  role: Role
  display_name?: string | null
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  checkAuth: () => Promise<void>
}

const AuthContext = React.createContext<AuthContextType | undefined>(undefined)

export function useAuth(): AuthContextType {
  const context = React.useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

interface AuthProviderProps {
  children: React.ReactNode
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = React.useState<User | null>(null)
  const [isLoading, setIsLoading] = React.useState(true)

  const checkAuth = React.useCallback(async () => {
    try {
      const response = (await apiGet<{ user: User }>("/auth/me")) as { user: User }
      if (response && response.user) {
        setUser(response.user)
      } else {
        setUser(null)
      }
    } catch (error) {
      // Not authenticated - this is fine
      setUser(null)
    } finally {
      setIsLoading(false)
    }
  }, [])

  React.useEffect(() => {
    checkAuth()
  }, [checkAuth])

  const login = React.useCallback(async (email: string, password: string) => {
    const response = (await apiPost<{ user: User }>("/auth/login", {
      email,
      password,
    })) as { user: User }
    if (response && response.user) {
      setUser(response.user)
    } else {
      throw new Error("Login failed: Invalid response")
    }
  }, [])

  const logout = React.useCallback(async () => {
    try {
      await apiPost("/auth/logout", {})
    } catch (error) {
      // Ignore logout errors
    } finally {
      setUser(null)
    }
  }, [])

  const value: AuthContextType = {
    user,
    isLoading,
    login,
    logout,
    checkAuth,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

