/**
 * App Component
 * 
 * Root React component with React Router setup.
 * Handles routing for claimant, coach, and admin flows.
 */

import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from "react-router-dom"
import { AuthProvider } from "@/contexts/AuthContext"
import { ToastProvider } from "@/contexts/ToastContext"
import { ToastContainer } from "@/components/shared/ToastContainer"
import { ProtectedRoute } from "@/components/routing/ProtectedRoute"
import { LoginPage } from "@/pages/LoginPage"
import { LandingPage } from "@/pages/LandingPage"
import { ClaimantDashboardContainer } from "@/pages/ClaimantDashboardContainer"
import { WorkCoachDashboardContainer } from "@/pages/WorkCoachDashboardContainer"
import { ClaimantDetailPage } from "@/pages/ClaimantDetailPage"
import { DWPDashboardContainer } from "@/pages/DWPDashboardContainer"
import { OnboardingPage } from "@/pages/OnboardingPage"
import { OnboardingConfirmationPage } from "@/pages/OnboardingConfirmationPage"
import { ApplicationBatchConfirmationPage } from "@/pages/ApplicationBatchConfirmationPage"
import { JobsPage } from "@/pages/JobsPage"
import { ApplicationHistoryPage } from "@/pages/ApplicationHistoryPage"
import { ComplianceLogPage } from "@/pages/ComplianceLogPage"
import { SettingsPage } from "@/pages/SettingsPage"
import { SupportPage } from "@/pages/SupportPage"
import { ClaimantAppShell } from "@/components/layout/ClaimantAppShell"
import { CoachAppShell } from "@/components/layout/CoachAppShell"
import { AdminAppShell } from "@/components/layout/AdminAppShell"
import { InstallPrompt } from "@/components/pwa"
import { useOnlineStatus } from "@/lib/useOnlineStatus"
import { OfflineBanner } from "@/components/shared/OfflineBanner"

// Wrapper component for OnboardingConfirmationPage to handle route state
function OnboardingConfirmationPageWrapper() {
  const location = useLocation()
  const navigate = useNavigate()
  const formData = location.state?.formData

  const handleComplete = () => {
    navigate("/app/dashboard", { replace: true })
  }

  const handleEdit = () => {
    navigate("/app/onboarding", { state: { formData } })
  }

  return (
    <ClaimantAppShell>
      <OnboardingConfirmationPage
        formData={formData}
        onComplete={handleComplete}
        onEdit={handleEdit}
      />
    </ClaimantAppShell>
  )
}


function App() {
  const isOnline = useOnlineStatus()

  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <OfflineBanner isOffline={!isOnline} />
          <InstallPrompt />
          <ToastContainer />
          <Routes>
          {/* Public routes */}
          <Route path="/login" element={<LoginPage />} />

          {/* Claimant routes */}
          <Route
            path="/app/onboarding"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <OnboardingPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/onboarding/confirmation"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <OnboardingConfirmationPageWrapper />
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/dashboard"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <ClaimantAppShell>
                  <ClaimantDashboardContainer />
                </ClaimantAppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/jobs"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <ClaimantAppShell>
                  <JobsPage />
                </ClaimantAppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/applications"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <ClaimantAppShell>
                  <ApplicationHistoryPage />
                </ClaimantAppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/applications/review"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <ClaimantAppShell>
                  <ApplicationBatchConfirmationPage />
                </ClaimantAppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/compliance"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <ClaimantAppShell>
                  <ComplianceLogPage />
                </ClaimantAppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/settings"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <ClaimantAppShell>
                  <SettingsPage />
                </ClaimantAppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/app/support"
            element={
              <ProtectedRoute allowedRoles={["claimant"]}>
                <ClaimantAppShell>
                  <SupportPage />
                </ClaimantAppShell>
              </ProtectedRoute>
            }
          />

          {/* Staff routes - Work Coach */}
          <Route
            path="/staff/work-coach"
            element={
              <ProtectedRoute allowedRoles={["coach", "admin"]}>
                <CoachAppShell>
                  <WorkCoachDashboardContainer />
                </CoachAppShell>
              </ProtectedRoute>
            }
          />
          <Route
            path="/staff/work-coach/claimants/:id"
            element={
              <ProtectedRoute allowedRoles={["coach", "admin"]}>
                <CoachAppShell>
                  <ClaimantDetailPage />
                </CoachAppShell>
              </ProtectedRoute>
            }
          />

          {/* Staff routes - Admin/DWP */}
          <Route
            path="/staff/dwp"
            element={
              <ProtectedRoute allowedRoles={["admin"]}>
                <AdminAppShell>
                  <DWPDashboardContainer />
                </AdminAppShell>
              </ProtectedRoute>
            }
          />

          {/* Public landing page */}
          <Route path="/" element={<LandingPage />} />

          {/* Catch all - redirect to login */}
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}

export default App
