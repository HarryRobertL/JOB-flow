/**
 * ApplicationBatchConfirmationPage Component
 * 
 * Summary screen before confirming a batch of applications.
 * Recaps number of roles, types, and how they'll appear in the compliance log.
 */

import * as React from "react"
import { CheckCircle, AlertCircle, FileText, Briefcase } from "lucide-react"
import { AppShell } from "@/components/layout/AppShell"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { EmptyState } from "@/components/shared/EmptyState"
import { ApplicationReviewCard, type ApplicationReview } from "@/components/applications/ApplicationReviewCard"
import { useAnalytics } from "@/lib/useAnalytics"
import { useToast } from "@/contexts/ToastContext"

export interface ApplicationBatchConfirmationPageProps {
  applications?: ApplicationReview[]
  onCancel?: () => void
  onSubmit?: (selectedIds: string[]) => Promise<void>
}

export const ApplicationBatchConfirmationPage: React.FC<ApplicationBatchConfirmationPageProps> = ({
  applications: propApplications = [],
  onCancel,
  onSubmit,
}) => {
  const { track } = useAnalytics()
  const { showToast } = useToast()
  const applications = propApplications
  const [selectedIds, setSelectedIds] = React.useState<Set<string>>(
    new Set(applications.map((app) => app.id))
  )
  const [isSubmitting, setIsSubmitting] = React.useState(false)

  if (applications.length === 0) {
    return (
      <AppShell appTitle="JobFlow" userName="Claimant">
        <div className="max-w-5xl mx-auto">
          <EmptyState
            title="No applications to review"
            description="There are no applications waiting for review at this time."
          />
        </div>
      </AppShell>
    )
  }

  const selectedApplications = applications.filter((app) => selectedIds.has(app.id))
  const autoApplyCount = selectedApplications.filter(
    (app) => app.status === "auto_queued" || app.status === "ready_to_submit"
  ).length
  const reviewCount = selectedApplications.filter(
    (app) => app.status === "pending_review"
  ).length

  // Group by job type/platform
  const byPlatform = React.useMemo(() => {
    const groups: Record<string, ApplicationReview[]> = {}
    selectedApplications.forEach((app) => {
      if (!groups[app.platform]) {
        groups[app.platform] = []
      }
      groups[app.platform].push(app)
    })
    return groups
  }, [selectedApplications])

  const byJobType = React.useMemo(() => {
    const groups: Record<string, ApplicationReview[]> = {}
    selectedApplications.forEach((app) => {
      // Simple grouping by keywords in title
      const title = app.jobTitle.toLowerCase()
      let type = "Other"
      if (title.includes("retail") || title.includes("shop") || title.includes("store")) {
        type = "Retail"
      } else if (title.includes("customer service") || title.includes("call centre")) {
        type = "Customer Service"
      } else if (title.includes("admin") || title.includes("office") || title.includes("reception")) {
        type = "Administration"
      } else if (title.includes("warehouse") || title.includes("logistics")) {
        type = "Warehouse/Logistics"
      }
      if (!groups[type]) {
        groups[type] = []
      }
      groups[type].push(app)
    })
    return groups
  }, [selectedApplications])

  const handleSelectChange = (id: string, selected: boolean) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (selected) {
        next.add(id)
      } else {
        next.delete(id)
      }
      return next
    })
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    try {
      // Track application submission event
      const selectedApplications = applications.filter((app) => selectedIds.has(app.id))
      const platforms = Array.from(new Set(selectedApplications.map((app) => app.platform)))
      const jobTypes = new Set<string>()
      selectedApplications.forEach((app) => {
        const title = app.jobTitle.toLowerCase()
        if (title.includes("retail") || title.includes("shop") || title.includes("store")) {
          jobTypes.add("Retail")
        } else if (title.includes("customer service") || title.includes("call centre")) {
          jobTypes.add("Customer Service")
        } else if (title.includes("admin") || title.includes("office") || title.includes("reception")) {
          jobTypes.add("Administration")
        } else if (title.includes("warehouse") || title.includes("logistics")) {
          jobTypes.add("Warehouse/Logistics")
        } else {
          jobTypes.add("Other")
        }
      })
      const autoApplyCount = selectedApplications.filter(
        (app) => app.status === "auto_queued" || app.status === "ready_to_submit"
      ).length
      const reviewCount = selectedApplications.filter(
        (app) => app.status === "pending_review"
      ).length

      await track({
        event: "job_application_submitted" as const,
        batchSize: selectedApplications.length,
        platforms: platforms,
        isAutoApply: autoApplyCount > 0,
        requiredReview: reviewCount > 0,
        jobTypesCount: jobTypes.size,
      } as any)

      if (onSubmit) {
        await onSubmit(Array.from(selectedIds))
      } else {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1500))
      }

      // Show success toast
      showToast({
        title: "Applications submitted",
        description: `${selectedApplications.length} application${selectedApplications.length !== 1 ? "s" : ""} submitted successfully.`,
        variant: "success",
      })
    } catch (error) {
      // Show error toast if submission fails
      showToast({
        title: "Submission failed",
        description: error instanceof Error ? error.message : "Failed to submit applications. Please try again.",
        variant: "error",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AppShell
      appTitle="JobFlow"
      userName="Claimant"
    >
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-text-primary">Review applications</h1>
          <p className="mt-2 text-sm text-text-secondary">
            Review and confirm the applications you want to submit
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid gap-4 sm:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-text-secondary">
                Total applications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-text-primary">
                {selectedApplications.length}
              </div>
              <p className="text-xs text-text-secondary mt-1">
                {selectedIds.size} of {applications.length} selected
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-text-secondary">
                Auto-apply
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary-600">
                {autoApplyCount}
              </div>
              <p className="text-xs text-text-secondary mt-1">
                Will be submitted automatically
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-text-secondary">
                Require review
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-warning-600">
                {reviewCount}
              </div>
              <p className="text-xs text-text-secondary mt-1">
                Need your approval first
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Breakdown by Type */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Breakdown by job type
            </CardTitle>
            <CardDescription>
              How these applications will be categorized
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {Object.entries(byJobType).map(([type, apps]) => (
                <div key={type} className="flex items-center justify-between p-3 rounded-lg border border-neutral-200">
                  <span className="text-sm font-medium text-text-primary">{type}</span>
                  <Badge variant="outline">{apps.length}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Breakdown by Platform */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Breakdown by platform
            </CardTitle>
            <CardDescription>
              Where these applications will be submitted
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {Object.entries(byPlatform).map(([platform, apps]) => (
                <div key={platform} className="flex items-center justify-between p-3 rounded-lg border border-neutral-200">
                  <span className="text-sm font-medium text-text-primary capitalize">{platform}</span>
                  <Badge variant="outline">{apps.length}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Compliance Log Info */}
        <Card className="border-primary-200 bg-primary-50">
          <CardHeader>
            <CardTitle className="text-primary-900 flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Compliance log
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-primary-800">
            <p>
              All {selectedApplications.length} application{selectedApplications.length !== 1 ? "s" : ""} will be
              automatically logged in your compliance record with the following information:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li>Job title and company name</li>
              <li>Application timestamp</li>
              <li>Platform where the application was submitted</li>
              <li>Application status (submitted, pending review, etc.)</li>
              <li>URL of the job listing</li>
            </ul>
            <p className="pt-2 border-t border-primary-200">
              <strong>Note:</strong> Your work coach can view this log to verify your job search activity.
              You can also export this log at any time from your dashboard.
            </p>
          </CardContent>
        </Card>

        {/* Application List */}
        <div>
          <h2 className="text-xl font-semibold text-text-primary mb-4">
            Applications to submit ({selectedApplications.length})
          </h2>
          <div className="space-y-4">
            {selectedApplications.map((application) => (
              <ApplicationReviewCard
                key={application.id}
                application={application}
                selected={selectedIds.has(application.id)}
                onSelectChange={handleSelectChange}
              />
            ))}
          </div>
        </div>

        {/* Actions */}
        <Card className="border-t-2">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-text-primary">
                  Ready to submit {selectedApplications.length} application{selectedApplications.length !== 1 ? "s" : ""}?
                </p>
                <p className="text-xs text-text-secondary">
                  {autoApplyCount > 0 && `${autoApplyCount} will be submitted automatically. `}
                  {reviewCount > 0 && `${reviewCount} require your review before submission.`}
                </p>
              </div>
              <div className="flex gap-3">
                {onCancel && (
                  <Button
                    variant="outline"
                    onClick={onCancel}
                    disabled={isSubmitting}
                  >
                    Cancel
                  </Button>
                )}
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting || selectedApplications.length === 0}
                  className="min-w-[120px]"
                >
                  {isSubmitting ? (
                    <>
                      <AlertCircle className="mr-2 h-4 w-4 animate-pulse" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Confirm & submit
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  )
}

