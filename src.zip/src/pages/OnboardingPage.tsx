/**
 * OnboardingPage Component
 * 
 * Multi-step onboarding flow for new claimants.
 * Collects profile, skills, location, and preferences.
 */

import * as React from "react"
import { useNavigate } from "react-router-dom"
import { AppShell } from "@/components/layout/AppShell"
import { StepIndicator } from "@/components/onboarding/StepIndicator"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FormField, FormErrorSummary, type FormError } from "@/components/forms"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useAnalytics } from "@/lib/useAnalytics"
import type { OnboardingCompletedEvent } from "@/lib/analytics"
import { apiPut } from "@/lib/apiClient"
import { useToast } from "@/contexts/ToastContext"

export interface OnboardingData {
  // Step 1: Profile
  email: string
  firstName: string
  lastName: string
  phone: string
  location: string
  postcode?: string
  city?: string
  address?: string

  // Step 2: Skills & Experience
  skills: string[]
  experience: string
  noticePeriod: string
  workAuthorization: string

  // Step 3: Job Preferences
  preferredJobTypes: string[]
  preferredLocations: string[]
  salaryMin?: number
  remotePreference: "remote" | "hybrid" | "onsite" | "any"
  maxCommuteDistance: number

  // Step 4: Automation Preferences
  autoApplyEnabled: boolean
  dailyCap?: number
  requireReview: boolean
  cvPath: string
  coverLetterTemplate: string
}

const STEPS = [
  { id: 1, label: "Profile", title: "Personal Information" },
  { id: 2, label: "Skills", title: "Skills & Experience" },
  { id: 3, label: "Preferences", title: "Job Preferences" },
  { id: 4, label: "Settings", title: "Automation Settings" },
]

export const OnboardingPage: React.FC = () => {
  const { track } = useAnalytics()
  const { showToast } = useToast()
  const navigate = useNavigate()
  const startTimeRef = React.useRef<number>(Date.now())
  const [currentStep, setCurrentStep] = React.useState(1)
  const [formData, setFormData] = React.useState<Partial<OnboardingData>>({
    remotePreference: "any",
    maxCommuteDistance: 25,
    autoApplyEnabled: true,
    requireReview: true,
  })
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [formErrors, setFormErrors] = React.useState<FormError[]>([])
  const [isSubmitting, setIsSubmitting] = React.useState(false)

  const updateField = (field: keyof OnboardingData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev }
        delete next[field]
        return next
      })
    }
  }

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {}
    const newFormErrors: FormError[] = []

    if (step === 1) {
      if (!formData.email) {
        newErrors.email = "Email is required"
        newFormErrors.push({ field: "email", message: "Email is required", id: "email" })
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        newErrors.email = "Please enter a valid email address"
        newFormErrors.push({ field: "email", message: "Please enter a valid email address", id: "email" })
      }
      if (!formData.firstName) {
        newErrors.firstName = "First name is required"
        newFormErrors.push({ field: "firstName", message: "First name is required", id: "firstName" })
      }
      if (!formData.lastName) {
        newErrors.lastName = "Last name is required"
        newFormErrors.push({ field: "lastName", message: "Last name is required", id: "lastName" })
      }
      if (!formData.phone) {
        newErrors.phone = "Phone number is required"
        newFormErrors.push({ field: "phone", message: "Phone number is required", id: "phone" })
      }
      if (!formData.location) {
        newErrors.location = "Location is required"
        newFormErrors.push({ field: "location", message: "Location is required", id: "location" })
      }
    }

    if (step === 2) {
      if (!formData.experience || formData.experience.trim().length < 10) {
        newErrors.experience = "Please provide a brief description of your experience (at least 10 characters)"
        newFormErrors.push({
          field: "experience",
          message: "Please provide a brief description of your experience",
          id: "experience",
        })
      }
      if (!formData.noticePeriod) {
        newErrors.noticePeriod = "Notice period is required"
        newFormErrors.push({ field: "noticePeriod", message: "Notice period is required", id: "noticePeriod" })
      }
      if (!formData.workAuthorization) {
        newErrors.workAuthorization = "Work authorization status is required"
        newFormErrors.push({
          field: "workAuthorization",
          message: "Work authorization status is required",
          id: "workAuthorization",
        })
      }
    }

    if (step === 3) {
      if (!formData.preferredJobTypes || formData.preferredJobTypes.length === 0) {
        newErrors.preferredJobTypes = "Please select at least one job type"
        newFormErrors.push({
          field: "preferredJobTypes",
          message: "Please select at least one job type",
        })
      }
    }

    if (step === 4) {
      if (!formData.cvPath) {
        newErrors.cvPath = "CV path is required"
        newFormErrors.push({ field: "cvPath", message: "CV path is required", id: "cvPath" })
      }
      if (!formData.coverLetterTemplate) {
        newErrors.coverLetterTemplate = "Cover letter template path is required"
        newFormErrors.push({
          field: "coverLetterTemplate",
          message: "Cover letter template path is required",
          id: "coverLetterTemplate",
        })
      }
    }

    setErrors(newErrors)
    setFormErrors(newFormErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNext = () => {
    if (validateStep(currentStep)) {
      if (currentStep < STEPS.length) {
        setCurrentStep(currentStep + 1)
        // Scroll to top
        window.scrollTo({ top: 0, behavior: "smooth" })
      }
      // If on last step, handleSubmit will be called by form submission
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const handleSubmit = async () => {
    if (isSubmitting) return

    setIsSubmitting(true)
    setFormErrors([])

    try {
      // Track onboarding completion
      const durationSeconds = Math.floor((Date.now() - startTimeRef.current) / 1000)
      const event: Omit<OnboardingCompletedEvent, "timestamp" | "sessionId"> = {
        event: "onboarding_completed",
        totalSteps: STEPS.length,
        durationSeconds,
        autoApplyEnabled: formData.autoApplyEnabled || false,
        requireReview: formData.requireReview || false,
        jobTypesCount: formData.preferredJobTypes?.length || 0,
        hasDailyCap: formData.dailyCap !== undefined && formData.dailyCap > 0,
      }
      await track(event)

      // Submit to backend API to create/update profile
      const profileData = {
        email: formData.email,
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        location: formData.location,
        postcode: formData.postcode,
        city: formData.city,
        address: formData.address,
        preferredJobTypes: formData.preferredJobTypes,
        preferredLocations: formData.preferredLocations,
        salaryMin: formData.salaryMin,
        remotePreference: formData.remotePreference,
        maxCommuteDistance: formData.maxCommuteDistance,
        autoApplyEnabled: formData.autoApplyEnabled,
        dailyCap: formData.dailyCap,
        requireReview: formData.requireReview,
        cvPath: formData.cvPath,
        coverLetterTemplate: formData.coverLetterTemplate,
      }

      await apiPut<{ status: string; message: string }>("/api/claimant/profile", profileData)

      // Show success toast
      showToast({
        title: "Profile saved successfully",
        description: "Your profile has been set up. You can now start applying to jobs.",
        variant: "success",
      })

      // Navigate to confirmation page with form data
      navigate("/app/onboarding/confirmation", {
        state: { formData },
        replace: true,
      })
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to save profile. Please try again."
      setFormErrors([
        {
          field: "submit",
          message: errorMessage,
          id: "submit-error",
        },
      ])
      // Scroll to top to show error
      window.scrollTo({ top: 0, behavior: "smooth" })
    } finally {
      setIsSubmitting(false)
    }
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <FormField
              label="Email address"
              name="email"
              id="email"
              required
              error={errors.email}
              description="We'll use this to send you updates about your applications"
            >
              <Input
                type="email"
                value={formData.email || ""}
                onChange={(e) => updateField("email", e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
                data-testid="onboarding-email"
              />
            </FormField>

            <div className="grid gap-6 sm:grid-cols-2">
              <FormField
                label="First name"
                name="firstName"
                id="firstName"
                required
                error={errors.firstName}
              >
                <Input
                  type="text"
                  value={formData.firstName || ""}
                  onChange={(e) => updateField("firstName", e.target.value)}
                  placeholder="John"
                  autoComplete="given-name"
                  data-testid="onboarding-first-name"
                />
              </FormField>

              <FormField
                label="Last name"
                name="lastName"
                id="lastName"
                required
                error={errors.lastName}
              >
                <Input
                  type="text"
                  value={formData.lastName || ""}
                  onChange={(e) => updateField("lastName", e.target.value)}
                  placeholder="Smith"
                  autoComplete="family-name"
                  data-testid="onboarding-last-name"
                />
              </FormField>
            </div>

            <FormField
              label="Phone number"
              name="phone"
              id="phone"
              required
              error={errors.phone}
              description="Include country code if outside UK"
            >
              <Input
                type="tel"
                value={formData.phone || ""}
                onChange={(e) => updateField("phone", e.target.value)}
                placeholder="+44 7700 900000"
                autoComplete="tel"
                data-testid="onboarding-phone"
              />
            </FormField>

            <FormField
              label="Location"
              name="location"
              id="location"
              required
              error={errors.location}
              description="City or town where you're based"
            >
              <Input
                type="text"
                value={formData.location || ""}
                onChange={(e) => updateField("location", e.target.value)}
                placeholder="Cardiff, UK"
              />
            </FormField>

            <div className="grid gap-6 sm:grid-cols-2">
              <FormField
                label="Postcode"
                name="postcode"
                id="postcode"
                error={errors.postcode}
                description="Optional, but helps with location matching"
              >
                <Input
                  type="text"
                  value={formData.postcode || ""}
                  onChange={(e) => updateField("postcode", e.target.value)}
                  placeholder="CF10 3AT"
                />
              </FormField>

              <FormField
                label="City"
                name="city"
                id="city"
                error={errors.city}
              >
                <Input
                  type="text"
                  value={formData.city || ""}
                  onChange={(e) => updateField("city", e.target.value)}
                  placeholder="Cardiff"
                />
              </FormField>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <FormField
              label="Work experience"
              name="experience"
              id="experience"
              required
              error={errors.experience}
              description="Brief summary of your work experience and key skills"
            >
              <Textarea
                value={formData.experience || ""}
                onChange={(e) => updateField("experience", e.target.value)}
                placeholder="Describe your work experience, skills, and qualifications..."
                rows={6}
              />
            </FormField>

            <FormField
              label="Notice period"
              name="noticePeriod"
              id="noticePeriod"
              required
              error={errors.noticePeriod}
              description="How much notice do you need to give your current employer?"
            >
              <Select
                value={formData.noticePeriod || ""}
                onChange={(e) => updateField("noticePeriod", e.target.value)}
              >
                <option value="">Select notice period</option>
                <option value="immediate">Immediate</option>
                <option value="1 week">1 week</option>
                <option value="2 weeks">2 weeks</option>
                <option value="1 month">1 month</option>
                <option value="2 months">2 months</option>
                <option value="3 months">3 months</option>
              </Select>
            </FormField>

            <FormField
              label="Right to work in the UK"
              name="workAuthorization"
              id="workAuthorization"
              required
              error={errors.workAuthorization}
              description="Your work authorization status"
            >
              <Select
                value={formData.workAuthorization || ""}
                onChange={(e) => updateField("workAuthorization", e.target.value)}
              >
                <option value="">Select status</option>
                <option value="uk_citizen">UK citizen</option>
                <option value="eu_settled">EU settled status</option>
                <option value="visa">Work visa</option>
                <option value="other">Other</option>
              </Select>
            </FormField>
          </div>
        )

      case 3:
        const jobTypes = [
          "Retail assistant",
          "Customer service",
          "Office administrator",
          "Warehouse operative",
          "Sales assistant",
          "Receptionist",
          "Data entry",
          "Other",
        ]

        return (
          <div className="space-y-6">
            <FormField
              label="Preferred job types"
              name="preferredJobTypes"
              id="preferredJobTypes"
              required
              error={errors.preferredJobTypes}
              description="Select all that apply"
            >
              <fieldset className="space-y-2">
                <legend className="sr-only">Select preferred job types</legend>
                {jobTypes.map((type) => (
                  <label
                    key={type}
                    className="flex items-center space-x-2 p-3 rounded-md border border-neutral-300 hover:bg-neutral-50 cursor-pointer focus-within:ring-2 focus-within:ring-primary-500 focus-within:ring-offset-2"
                  >
                    <input
                      type="checkbox"
                      checked={formData.preferredJobTypes?.includes(type) || false}
                      onChange={(e) => {
                        const current = formData.preferredJobTypes || []
                        const updated = e.target.checked
                          ? [...current, type]
                          : current.filter((t) => t !== type)
                        updateField("preferredJobTypes", updated)
                      }}
                      className="rounded border-neutral-300 text-primary-500 focus:ring-primary-500"
                      aria-label={`Select ${type} as preferred job type`}
                      data-testid={`job-type-${type.toLowerCase().replace(/\s+/g, '-')}`}
                    />
                    <span className="text-sm">{type}</span>
                  </label>
                ))}
              </fieldset>
            </FormField>

            <FormField
              label="Remote work preference"
              name="remotePreference"
              id="remotePreference"
              error={errors.remotePreference}
            >
              <Select
                value={formData.remotePreference || "any"}
                onChange={(e) => updateField("remotePreference", e.target.value)}
              >
                <option value="any">Any (remote, hybrid, or onsite)</option>
                <option value="remote">Remote only</option>
                <option value="hybrid">Hybrid (mix of remote and onsite)</option>
                <option value="onsite">Onsite only</option>
              </Select>
            </FormField>

            <FormField
              label="Maximum commute distance"
              name="maxCommuteDistance"
              id="maxCommuteDistance"
              error={errors.maxCommuteDistance}
              description="Maximum distance you're willing to commute (in kilometers)"
            >
              <Input
                type="number"
                min="1"
                max="100"
                value={formData.maxCommuteDistance || 25}
                onChange={(e) => updateField("maxCommuteDistance", parseInt(e.target.value) || 25)}
              />
            </FormField>

            <FormField
              label="Minimum salary (optional)"
              name="salaryMin"
              id="salaryMin"
              error={errors.salaryMin}
              description="Minimum annual salary in GBP"
            >
              <Input
                type="number"
                min="0"
                value={formData.salaryMin || ""}
                onChange={(e) => updateField("salaryMin", e.target.value ? parseInt(e.target.value) : undefined)}
                placeholder="22000"
              />
            </FormField>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <div className="rounded-lg border border-neutral-200 bg-neutral-50 p-4">
              <Label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.autoApplyEnabled || false}
                  onChange={(e) => updateField("autoApplyEnabled", e.target.checked)}
                  className="rounded border-neutral-300 text-primary-500 focus:ring-primary-500"
                />
                <span className="text-sm font-medium">Enable automatic application</span>
              </Label>
              <p className="mt-2 text-xs text-text-secondary ml-6">
                When enabled, JobFlow will automatically submit applications for jobs that match your criteria.
                You can review applications before they're submitted if you prefer.
              </p>
            </div>

            {formData.autoApplyEnabled && (
              <FormField
                label="Daily application cap"
                name="dailyCap"
                id="dailyCap"
                error={errors.dailyCap}
                description="Maximum number of applications per day (leave empty for no limit)"
              >
                <Input
                  type="number"
                  min="1"
                  value={formData.dailyCap || ""}
                  onChange={(e) => updateField("dailyCap", e.target.value ? parseInt(e.target.value) : undefined)}
                  placeholder="15"
                />
              </FormField>
            )}

            <div className="rounded-lg border border-neutral-200 bg-neutral-50 p-4">
              <Label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.requireReview || false}
                  onChange={(e) => updateField("requireReview", e.target.checked)}
                  className="rounded border-neutral-300 text-primary-500 focus:ring-primary-500"
                />
                <span className="text-sm font-medium">Require manual review before submission</span>
              </Label>
              <p className="mt-2 text-xs text-text-secondary ml-6">
                When enabled, you'll be notified to review each application before it's submitted.
                This gives you more control but requires more time.
              </p>
            </div>

            <FormField
              label="CV file path"
              name="cvPath"
              id="cvPath"
              required
              error={errors.cvPath}
              description="Full path to your CV PDF file"
            >
              <Input
                type="text"
                value={formData.cvPath || ""}
                onChange={(e) => updateField("cvPath", e.target.value)}
                placeholder="/path/to/your/cv.pdf"
              />
            </FormField>

            <FormField
              label="Cover letter template path"
              name="coverLetterTemplate"
              id="coverLetterTemplate"
              required
              error={errors.coverLetterTemplate}
              description="Full path to your cover letter template file"
            >
              <Input
                type="text"
                value={formData.coverLetterTemplate || ""}
                onChange={(e) => updateField("coverLetterTemplate", e.target.value)}
                placeholder="/path/to/cover_letter_template.md"
              />
            </FormField>
          </div>
        )

      default:
        return null
    }
  }


  return (
    <AppShell
      appTitle="JobFlow"
      userName="New User"
    >
      <div className="max-w-3xl mx-auto space-y-8" data-testid="onboarding-page">
        <header>
          <h1 className="text-3xl font-bold text-text-primary">Get started with JobFlow</h1>
          <p className="mt-2 text-sm text-text-secondary">
            We'll help you set up your profile and preferences in a few simple steps
          </p>
        </header>

        <Card>
          <CardHeader>
            <nav aria-label="Onboarding steps">
              <StepIndicator
                currentStep={currentStep}
                totalSteps={STEPS.length}
                stepLabels={STEPS.map((s) => s.label)}
              />
            </nav>
            <CardTitle className="mt-6" id="step-title">{STEPS[currentStep - 1].title}</CardTitle>
            <CardDescription id="step-description">
              {currentStep === 1 && "Tell us about yourself"}
              {currentStep === 2 && "Share your skills and experience"}
              {currentStep === 3 && "Set your job search preferences"}
              {currentStep === 4 && "Configure automation settings"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {formErrors.length > 0 && (
              <FormErrorSummary errors={formErrors} />
            )}

            <form 
              onSubmit={(e) => {
                e.preventDefault()
                if (currentStep === STEPS.length) {
                  handleSubmit()
                } else {
                  handleNext()
                }
              }}
              aria-labelledby="step-title"
              aria-describedby="step-description"
              noValidate
            >
              {renderStepContent()}

              <div className="flex justify-between pt-6 border-t">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleBack}
                  disabled={currentStep === 1}
                  aria-label={currentStep === 1 ? "Cannot go back, on first step" : "Go to previous step"}
                  data-testid="onboarding-back-button"
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  data-testid="onboarding-next-button"
                  disabled={isSubmitting}
                >
                  {isSubmitting
                    ? "Saving..."
                    : currentStep === STEPS.length
                    ? "Complete setup"
                    : "Next"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  )
}

