/**
 * Landing Page
 * 
 * Public landing page for JobFlow.
 * Provides information about the tool and links to login.
 */

import { useEffect } from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Briefcase, CheckCircle, BarChart3, Shield } from "lucide-react"
import { useAnalytics } from "@/lib/useAnalytics"

export function LandingPage() {
  const { track } = useAnalytics()

  useEffect(() => {
    // Track landing page view
    track({
      event: "landing_page_viewed",
      timestamp: new Date().toISOString(),
    } as any)
  }, [track])
  return (
    <div className="min-h-screen bg-background-default">
      {/* Header */}
      <header className="border-b border-border-default bg-surface-DEFAULT">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img
                src="/typeface-logo.png"
                alt="JobFlow"
                className="h-8 object-contain"
              />
            </div>
            <Link to="/login">
              <Button variant="outline">Sign in</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-20">
        <div className="text-center">
          <h1 className="text-3xl font-bold leading-tight tracking-tight text-text-primary sm:text-4xl lg:text-5xl">
            Meet Your Job Search Requirements
            <span className="block text-primary-600">With Automated Applications</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-text-secondary">
            JobFlow is a DWP pilot tool that helps Universal Credit claimants automatically find and apply to suitable jobs.
            It automates some applications and keeps a clear log for your work coach, helping you meet your job search requirements while reducing the burden of manual searching.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/login">
              <Button size="lg">Get started</Button>
            </Link>
            <a
              href="#features"
              className="text-sm font-medium text-primary-600 hover:text-primary-700 underline-offset-4 hover:underline"
            >
              Learn more
            </a>
          </div>
        </div>

        {/* Features - Split by Audience */}
        <div id="features" className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-semibold leading-tight text-text-primary">How JobFlow Works</h2>
            <p className="mt-2 text-base text-text-secondary">
              Designed for both claimants and DWP staff
            </p>
          </div>

          {/* For Claimants */}
          <div className="mb-16">
            <h3 className="text-xl font-semibold leading-snug text-text-primary mb-6 pb-2 border-b border-neutral-200">
              For Claimants
            </h3>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader>
                  <Briefcase className="h-8 w-8 text-primary-600" />
                  <CardTitle>Automated Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Automatically find and apply to suitable jobs on Indeed, Greenhouse, and Lever based on your skills and preferences.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CheckCircle className="h-8 w-8 text-success-600" />
                  <CardTitle>Stay Compliant</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Track your application activity and maintain compliance with DWP job search requirements automatically.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <BarChart3 className="h-8 w-8 text-info-600" />
                  <CardTitle>Progress Tracking</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Monitor your application progress with detailed analytics and activity logs to see your job search journey.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Shield className="h-8 w-8 text-warning-600" />
                  <CardTitle>Privacy First</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Your data is secure and private. All credentials are stored locally on your device for maximum security.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* For DWP Staff */}
          <div>
            <h3 className="text-xl font-semibold leading-snug text-text-primary mb-6 pb-2 border-b border-neutral-200">
              For DWP Staff
            </h3>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <BarChart3 className="h-8 w-8 text-primary-600" />
                  <CardTitle>Real-time Monitoring</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Monitor claimant compliance status, application activity, and engagement metrics in real-time.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CheckCircle className="h-8 w-8 text-success-600" />
                  <CardTitle>Compliance Tracking</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Track compliance with job search requirements and identify claimants who may need additional support.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Shield className="h-8 w-8 text-info-600" />
                  <CardTitle>Pilot Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Access aggregated metrics and insights to evaluate the pilot program's effectiveness and outcomes.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20 rounded-lg bg-primary-600 p-8 sm:p-12 text-center text-white">
          <h2 className="text-2xl font-semibold leading-tight sm:text-3xl">Ready to get started?</h2>
          <p className="mt-2 text-base text-primary-100 max-w-2xl mx-auto">
            Get started with JobFlow to automate your job applications and keep a clear log for your work coach.
          </p>
          <Link to="/login" className="mt-6 inline-block">
            <Button size="lg" variant="secondary" className="bg-white text-primary-600 hover:bg-neutral-50">
              Get started
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-neutral-200 bg-white py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-text-secondary">
            JobFlow - Department for Work and Pensions
          </p>
        </div>
      </footer>
    </div>
  )
}

