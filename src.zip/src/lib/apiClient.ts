/**
 * API Client
 * 
 * Utility for making authenticated API requests to the FastAPI backend.
 * Automatically handles cookies for session-based auth.
 */

export interface ApiError {
  detail: string
}

/**
 * Check if an error is due to offline status
 */
export function isOfflineError(error: unknown): boolean {
  if (error instanceof Error) {
    // Network errors typically indicate offline
    const message = error.message.toLowerCase()
    return (
      message.includes("failed to fetch") ||
      message.includes("networkerror") ||
      message.includes("network error") ||
      message.includes("load failed") ||
      // Check navigator.onLine as well
      (typeof navigator !== "undefined" && !navigator.onLine)
    )
  }
  // Also check navigator.onLine for non-Error cases
  return typeof navigator !== "undefined" && !navigator.onLine
}

/**
 * Make an authenticated API request.
 * Cookies are automatically included by the browser.
 */
export async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  // Use empty string for same-origin requests (cookies will work)
  const baseUrl = import.meta.env.VITE_API_BASE_URL || ""
  // Ensure endpoint starts with /
  const normalizedEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`
  const url = `${baseUrl}${normalizedEndpoint}`

  let response: Response
  try {
    response = await fetch(url, {
      ...options,
      credentials: "include", // Include cookies
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
    })
  } catch (fetchError) {
    // Network errors (offline, CORS, etc.) are caught here
    if (isOfflineError(fetchError)) {
      throw new Error("You are offline. Please check your internet connection.")
    }
    throw fetchError
  }

  if (!response.ok) {
    let errorDetail = "An error occurred"
    try {
      const errorData = (await response.json()) as ApiError
      errorDetail = errorData.detail || errorDetail
    } catch {
      errorDetail = response.statusText || errorDetail
    }
    throw new Error(errorDetail)
  }

  // Handle empty responses
  const contentType = response.headers.get("content-type")
  if (contentType && contentType.includes("application/json")) {
    return (await response.json()) as T
  }
  
  return undefined as T
}

/**
 * GET request helper
 */
export async function apiGet<T>(endpoint: string): Promise<T> {
  return apiRequest<T>(endpoint, { method: "GET" })
}

/**
 * POST request helper
 */
export async function apiPost<T>(endpoint: string, data?: unknown): Promise<T> {
  return apiRequest<T>(endpoint, {
    method: "POST",
    body: data ? JSON.stringify(data) : undefined,
  })
}

/**
 * PUT request helper
 */
export async function apiPut<T>(endpoint: string, data?: unknown): Promise<T> {
  return apiRequest<T>(endpoint, {
    method: "PUT",
    body: data ? JSON.stringify(data) : undefined,
  })
}

/**
 * DELETE request helper
 */
export async function apiDelete<T>(endpoint: string): Promise<T> {
  return apiRequest<T>(endpoint, { method: "DELETE" })
}

/**
 * Start automation run
 * Triggers the JobFlow engine in a background thread.
 */
export interface RunResponse {
  status: "started" | "error"
  message?: string
}

export async function startAutomationRun(discoverOnly?: boolean): Promise<RunResponse> {
  const baseUrl = import.meta.env.VITE_API_BASE_URL || ""
  const url = `${baseUrl}/run${discoverOnly ? "?discover_only=true" : ""}`

  const response = await fetch(url, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  })

  // The /run endpoint returns a redirect (303), but we treat 200-399 as success
  if (response.status >= 200 && response.status < 400) {
    return {
      status: "started",
      message: "Automation run started successfully",
    }
  }

  let errorDetail = "Failed to start automation run"
  try {
    const errorData = (await response.json()) as ApiError
    errorDetail = errorData.detail || errorDetail
  } catch {
    errorDetail = response.statusText || errorDetail
  }

  throw new Error(errorDetail)
}

