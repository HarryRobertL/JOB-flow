/**
 * ProtectedRoute Component
 * 
 * Route guard that ensures user is authenticated and has required role.
 * Redirects to login if not authenticated, or to appropriate dashboard if wrong role.
 */

import * as React from "react"
import { Navigate, useLocation } from "react-router-dom"
import { useAuth } from "@/contexts/AuthContext"
import type { Role } from "@/contexts/AuthContext"

export interface ProtectedRouteProps {
  children: React.ReactNode
  allowedRoles: Role[]
  redirectTo?: string
}

export function ProtectedRoute({
  children,
  allowedRoles,
  redirectTo,
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth()
  const location = useLocation()

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500 mx-auto"></div>
          <p className="mt-4 text-sm text-text-secondary">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    // Not authenticated - redirect to login
    return <Navigate to="/login" state={{ from: location }} replace />
  }

  if (!allowedRoles.includes(user.role)) {
    // Wrong role - redirect to appropriate dashboard
    const defaultRedirect = redirectTo || getDefaultDashboardForRole(user.role)
    return <Navigate to={defaultRedirect} replace />
  }

  return <>{children}</>
}

function getDefaultDashboardForRole(role: Role): string {
  switch (role) {
    case "claimant":
      return "/app/dashboard"
    case "coach":
      return "/staff/work-coach"
    case "admin":
      return "/staff/dwp"
    default:
      return "/login"
  }
}

