/**
 * Button Component
 * 
 * shadcn UI compatible button component for JobFlow.
 * Provides accessible, styled buttons with variants for different use cases.
 */

import * as React from "react"
import { cn } from "@/lib/utils"

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
  size?: "default" | "sm" | "lg" | "icon"
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", ...props }, ref) => {
    return (
      <button
        className={cn(
          "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors duration-150",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2",
          "disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed",
          "min-h-[44px] min-w-[44px] sm:min-h-[40px] sm:min-w-[40px]", // WCAG AA touch target size
          {
            // Variants
            "bg-primary-500 text-offWhite-DEFAULT hover:bg-primary-600 active:bg-primary-700": variant === "default",
            "bg-error-500 text-offWhite-DEFAULT hover:bg-error-600 active:bg-error-700": variant === "destructive",
            "border border-border-default bg-transparent hover:bg-surface-alt active:bg-surface-elevated text-text-primary": variant === "outline",
            "bg-surface-alt text-text-primary hover:bg-surface-elevated active:bg-neutral-800": variant === "secondary",
            "hover:bg-surface-alt hover:text-text-primary active:bg-surface-elevated": variant === "ghost",
            "text-primary-500 underline-offset-4 hover:underline hover:text-primary-600": variant === "link",
            // Sizes
            "h-10 px-4 py-2": size === "default",
            "h-9 px-3 text-sm": size === "sm",
            "h-11 px-8 text-base": size === "lg",
            "h-10 w-10 p-0": size === "icon",
          },
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button }

