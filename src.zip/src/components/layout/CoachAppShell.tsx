/**
 * CoachAppShell Component
 * 
 * Layout shell specifically for work coach users.
 * Includes navigation for coach-specific routes.
 */

import * as React from "react"
import { useNavigate, useLocation } from "react-router-dom"
import { useAuth } from "@/contexts/AuthContext"
import { cn } from "@/lib/utils"
import { Sidebar, SidebarBody, SidebarLink } from "@/components/ui/sidebar"
import { Logo, LogoIcon } from "@/components/ui/sidebar-demo"
import { AppHeader } from "./AppHeader"
import { Users, Calendar, AlertTriangle, FileText } from "lucide-react"

export interface CoachAppShellProps {
  children: React.ReactNode
}

export const CoachAppShell: React.FC<CoachAppShellProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = React.useState(false)
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = async () => {
    await logout()
    navigate("/login")
  }

  const navLinks = [
    {
      label: "Claimants",
      href: "/staff/work-coach",
      icon: <Users className="h-5 w-5 flex-shrink-0" aria-hidden="true" />,
    },
    {
      label: "Appointments",
      href: "/staff/work-coach/appointments",
      icon: <Calendar className="h-5 w-5 flex-shrink-0" aria-hidden="true" />,
    },
    {
      label: "Compliance",
      href: "/staff/work-coach/compliance",
      icon: <AlertTriangle className="h-5 w-5 flex-shrink-0" aria-hidden="true" />,
    },
    {
      label: "Reports",
      href: "/staff/work-coach/reports",
      icon: <FileText className="h-5 w-5 flex-shrink-0" aria-hidden="true" />,
    },
  ]

  const isActive = (href: string) => location.pathname === href || location.pathname.startsWith(href + "/")

  return (
    <div className="flex h-screen overflow-hidden bg-background-secondary">
      {/* Skip to content link */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-modal focus:px-4 focus:py-2 focus:bg-primary-600 focus:text-white focus:rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
      >
        Skip to main content
      </a>

      <nav aria-label="Main navigation" role="navigation">
        <Sidebar open={sidebarOpen} setOpen={setSidebarOpen}>
          <SidebarBody className="justify-between gap-10">
            <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
              <div aria-label="JobFlow">{sidebarOpen ? <Logo /> : <LogoIcon />}</div>

              <ul className="mt-8 flex flex-col gap-2" role="list">
                {navLinks.map((link) => {
                  const active = isActive(link.href)
                  return (
                    <li key={link.href}>
                      <SidebarLink
                        link={link}
                        className={cn(
                          "relative transition-colors",
                          active && "bg-surface-alt text-text-primary font-medium",
                          active && "before:absolute before:left-0 before:top-0 before:bottom-0 before:w-1 before:bg-primary-600 before:rounded-r"
                        )}
                        aria-current={active ? "page" : undefined}
                      />
                    </li>
                  )
                })}
              </ul>
            </div>
          </SidebarBody>
        </Sidebar>
      </nav>

      <div className="flex flex-1 flex-col overflow-hidden">
        <AppHeader
          userName={user?.display_name || undefined}
          userEmail={user?.email || undefined}
          role={user?.role || "coach"}
          environmentBadge="Pilot"
          onLogout={handleLogout}
        />

        <main
          id="main-content"
          className="flex-1 overflow-y-auto bg-background-secondary"
          role="main"
          aria-label="Main content"
        >
          <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">{children}</div>
        </main>
      </div>
    </div>
  )
}

